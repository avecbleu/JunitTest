package tests;

public class UnitTesting {

	public int square (int n) {
		return n*n;
		
	}
	
}
